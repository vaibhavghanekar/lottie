package com.airbnb.lottie.samples

enum class LottiefilesMode {
    Popular,
    Recent,
    Search
}
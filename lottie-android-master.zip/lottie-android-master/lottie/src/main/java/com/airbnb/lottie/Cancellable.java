package com.airbnb.lottie;

public interface Cancellable {
  void cancel();
}

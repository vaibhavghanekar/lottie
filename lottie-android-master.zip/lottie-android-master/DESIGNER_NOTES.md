* Expressions are not supported.
* Text is not supported.
* If you have an Illustrator layer, convert it to a shape layer or else it will be exported as a 
bitmap.
* The smaller the content in a masked or matted layer is, the better the performance will be.
* Opacity is applied to individual elements not entire layers/groups. This can affect the 
appearance of overlapping items when the group or layer has opacity.